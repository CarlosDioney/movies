import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { properties } from '../../../assets/properties/properties';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  logo = properties.logo;
  formlogin: FormGroup = new FormGroup({});

  constructor(
    private fb: FormBuilder,
  ){
  }

  ngOnInit(): void{
    this.formlogin = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required]
    });
  }


  login(){
    if (this.formlogin.invalid){
      this.formlogin.markAllAsTouched();
      for (const key in this.formlogin.controls){
        //console.log(key);
        this.formlogin.controls[key].markAsDirty();
      }
      return;
    }
    console.log();
  }

}
