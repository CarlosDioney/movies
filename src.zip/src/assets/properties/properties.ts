export const properties ={
  logo: 'https://media.istockphoto.com/id/1438347708/es/vector/pc-de-escritorio-3d-con-bloqueo-de-escudo-y-contrase%C3%B1a.jpg?s=1024x1024&w=is&k=20&c=PT3Uyd5q7hAzqm9bn9hpe_gSr4tKyJfPODO4V_MJciI='
}
